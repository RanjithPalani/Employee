package com.example.app14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App14Application {

	public static void main(String[] args) {
		SpringApplication.run(App14Application.class, args);
	}

}

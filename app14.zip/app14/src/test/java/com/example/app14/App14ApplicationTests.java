package com.example.app14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
